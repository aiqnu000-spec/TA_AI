"""
API cho giao diện web AI_QNU (Giai đoạn web).  Chạy:

    uvicorn rag_api:app --port 8000

  POST /api/chat     {"question": "..."}  -> luồng NDJSON: sources, token..., done
  GET  /api/source   ?source=a.pdf&chunk=3 -> nội dung chunk + toạ độ bôi sáng trên trang PDF
  GET  /api/page     ?source=a.pdf&page=3  -> ảnh PNG của trang
  GET  /api/file     ?source=a.pdf         -> tải file gốc
  GET  /api/docs, POST /api/ingest, GET /api/health
"""
import json
import re
import threading

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response, StreamingResponse
from pydantic import BaseModel

from rag import embedder, settings
from rag.highlight import locate, render_page
from rag.ingest import ingest
from rag.query import stream_answer
from rag.store import Store

app = FastAPI(title="AI_QNU RAG API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

_store: Store | None = None
_lock = threading.RLock()   # RLock: run_ingest giữ khóa rồi gọi get_store() cũng cần khóa


def get_store() -> Store:
    global _store
    with _lock:
        if _store is None:
            _store = Store()
        return _store


def doc_path(source: str):
    """Đổi đường dẫn tương đối -> đường dẫn thật, chặn kiểu ../../ thoát khỏi thư mục kho."""
    root = settings.DOCS_DIR.resolve()
    path = (root / source).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise HTTPException(404, "Không tìm thấy tài liệu")
    return path


def is_pdf(source: str, page: int) -> bool:
    return source.lower().endswith(".pdf") and page > 0


class ChatIn(BaseModel):
    question: str


def _line(obj: dict) -> str:
    return json.dumps(obj, ensure_ascii=False) + "\n"


@app.post("/api/chat")
def chat(body: ChatIn):
    question = body.question.strip()
    if not question:
        raise HTTPException(400, "Câu hỏi trống")

    def generate():
        try:
            problems = embedder.check_ollama()
            if problems:
                yield _line({"type": "error", "message": " ".join(problems)})
                return
            hits, text = [], ""
            for kind, value in stream_answer(get_store(), question):
                if kind == "sources":
                    hits = value
                    yield _line({"type": "sources", "sources": [
                        {"n": i, "source": h.source, "page": h.page, "chunk": h.chunk,
                         "score": round(h.score, 3), "preview": h.text[:220],
                         "kind": "pdf" if is_pdf(h.source, h.page) else "text"}
                        for i, h in enumerate(hits, start=1)]})
                else:
                    text += value
                    yield _line({"type": "token", "text": value})
            cited = sorted({int(n) for n in re.findall(r"\[(\d+)\]", text) if 1 <= int(n) <= len(hits)})
            yield _line({"type": "done", "cited": cited})
        except Exception as e:  # noqa: BLE001
            yield _line({"type": "error", "message": str(e)})

    return StreamingResponse(generate(), media_type="application/x-ndjson",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.get("/api/source")
def source(source: str, chunk: int):
    hit = get_store().get_chunk(source, chunk)
    if hit is None:
        raise HTTPException(404, "Không tìm thấy đoạn này trong index")
    out = {"source": hit.source, "page": hit.page, "chunk": hit.chunk, "text": hit.text,
           "kind": "pdf" if is_pdf(hit.source, hit.page) else "text", "highlight": None}
    if out["kind"] == "pdf":
        try:
            out["highlight"] = locate(doc_path(hit.source), hit.page, hit.text)
        except HTTPException:
            raise
        except Exception as e:  # noqa: BLE001  (vẫn trả text để người dùng xem được)
            out["highlight"] = {"found": False, "rects": [], "error": str(e)}
    return out


@app.get("/api/page")
def page(source: str, page: int, zoom: float = Query(1.6, ge=0.5, le=4)):
    try:
        png = render_page(doc_path(source), page, zoom)
    except ValueError as e:
        raise HTTPException(404, str(e))
    return Response(png, media_type="image/png", headers={"Cache-Control": "public, max-age=3600"})


@app.get("/api/file")
def file(source: str):
    return FileResponse(doc_path(source))


@app.get("/api/docs")
def docs():
    return [d.__dict__ for d in get_store().list_docs()]


@app.post("/api/ingest")
def run_ingest(force: bool = False):
    with _lock:
        rep = ingest(get_store(), force=force)
    return {"added": rep.added, "updated": rep.updated, "unchanged": rep.unchanged,
            "removed": rep.removed, "errors": rep.errors, "needs_ocr": rep.needs_ocr}


@app.get("/api/health")
def health():
    return {"ollama_problems": embedder.check_ollama(), "stats": get_store().stats()}
