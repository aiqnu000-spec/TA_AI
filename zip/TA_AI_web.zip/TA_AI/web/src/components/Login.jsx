import { useState } from "react";
import { login, register } from "../lib/auth";

export default function Login({ onLogin, theme, onToggleTheme }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setError("");
    const email = form.email.trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) return setError("Email không hợp lệ");
    if (form.password.length < 6) return setError("Mật khẩu tối thiểu 6 ký tự");
    try {
      const data = { name: form.name.trim(), email, password: form.password };
      onLogin(mode === "register" ? await register(data) : await login(data));
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="login">
      <button className="icon-btn corner" onClick={onToggleTheme} title="Đổi giao diện">
        {theme === "dark" ? "☀️" : "🌙"}
      </button>
      <form className="card" onSubmit={submit}>
        <div className="logo big">QNU</div>
        <h1>AI_QNU</h1>
        <p>{mode === "login" ? "Đăng nhập để bắt đầu trò chuyện" : "Tạo tài khoản mới"}</p>

        {mode === "register" && <input placeholder="Tên hiển thị" value={form.name} onChange={set("name")} />}
        <input type="email" placeholder="Email" value={form.email} onChange={set("email")} />
        <input type="password" placeholder="Mật khẩu" value={form.password} onChange={set("password")} />

        {error && <div className="error">{error}</div>}
        <button className="primary" type="submit">{mode === "login" ? "Đăng nhập" : "Đăng ký"}</button>

        <div className="switch">
          {mode === "login" ? "Chưa có tài khoản? " : "Đã có tài khoản? "}
          <button type="button" onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}>
            {mode === "login" ? "Đăng ký" : "Đăng nhập"}
          </button>
        </div>
      </form>
    </div>
  );
}
