import { useState } from "react";
import AccountMenu from "./AccountMenu";

export default function Sidebar({
  user, chats, activeId, open, collapsed,
  onCollapse, onNew, onSelect, onPin, onRename, onDelete,
  menuProps,
}) {
  const [query, setQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [editVal, setEditVal] = useState("");

  const q = query.trim().toLowerCase();
  const filtered = chats.filter(
    (c) => !q || (c.title + " " + c.msgs.map((m) => m.content).join(" ")).toLowerCase().includes(q)
  );
  const pinned = filtered.filter((c) => c.pin);
  const recent = filtered.filter((c) => !c.pin);

  function commitRename() {
    const v = editVal.trim();
    if (v && editId) onRename(editId, v);
    setEditId(null);
  }

  const renderItem = (c) => (
    <div key={c.id} className={"item" + (c.id === activeId ? " on" : "")} onClick={() => onSelect(c.id)}>
      {editId === c.id ? (
        <input
          className="rename" autoFocus value={editVal}
          onClick={(e) => e.stopPropagation()}
          onChange={(e) => setEditVal(e.target.value)}
          onBlur={commitRename}
          onKeyDown={(e) => {
            if (e.key === "Enter") commitRename();
            if (e.key === "Escape") setEditId(null);
          }}
        />
      ) : (
        <>
          <span>{c.title}</span>
          <span className="acts">
            <b title="Ghim" onClick={(e) => { e.stopPropagation(); onPin(c.id); }}>{c.pin ? "📍" : "📌"}</b>
            <b title="Đổi tên" onClick={(e) => { e.stopPropagation(); setEditId(c.id); setEditVal(c.title); }}>✎</b>
            <b title="Xóa" onClick={(e) => { e.stopPropagation(); onDelete(c.id); }}>✕</b>
          </span>
        </>
      )}
    </div>
  );

  const close = (fn) => () => { setMenuOpen(false); fn(); };

  return (
    <aside className={"side" + (open ? " open" : "") + (collapsed ? " col" : "")}>
      <div className="brand">
        <div className="logo">QNU</div>AI_QNU
        <button className="icon-btn" title="Thu gọn thanh bên" onClick={onCollapse}>«</button>
      </div>

      <button className="new" onClick={onNew}>＋ Cuộc trò chuyện mới</button>
      <input className="search" placeholder="🔍 Tìm kiếm cuộc trò chuyện" value={query} onChange={(e) => setQuery(e.target.value)} />

      <div className="list">
        {pinned.length > 0 && <div className="label">Đã ghim</div>}
        {pinned.map(renderItem)}
        {pinned.length > 0 && recent.length > 0 && <div className="label">Gần đây</div>}
        {recent.map(renderItem)}
        {filtered.length === 0 && <div className="label">{q ? "Không tìm thấy kết quả" : "Chưa có cuộc trò chuyện"}</div>}
      </div>

      <div className="foot">
        {menuOpen && (
          <AccountMenu
            theme={menuProps.theme}
            onProfile={close(menuProps.onProfile)}
            onPassword={close(menuProps.onPassword)}
            onToggleTheme={close(menuProps.onToggleTheme)}
            onExport={close(menuProps.onExport)}
            onClear={close(menuProps.onClear)}
            onLogout={menuProps.onLogout}
          />
        )}
        <button className="account" onClick={() => setMenuOpen((o) => !o)}>
          <div className="avatar">{user.name[0].toUpperCase()}</div>
          <div className="who"><b>{user.name}</b><small>{user.email}</small></div>
          <span>⌃</span>
        </button>
      </div>
    </aside>
  );
}
