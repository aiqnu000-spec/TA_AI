import { useEffect, useRef, useState } from "react";
import { fileUrl, getSource, pageUrl } from "../lib/api";

const baseName = (p) => p.split("/").pop();

// Bảng bên phải: hiện đúng trang PDF mà RAG đã lấy, kèm vùng được bôi sáng
export default function SourcePanel({ sources, cited = [], active, onSelect, onClose }) {
  const src = sources.find((s) => s.n === active) || sources[0];
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [zoom, setZoom] = useState(1);
  const scroller = useRef(null);
  const pagebox = useRef(null);

  useEffect(() => {
    let stale = false;
    setData(null);
    setError("");
    getSource(src.source, src.chunk)
      .then((d) => !stale && setData(d))
      .catch((e) => !stale && setError(e.message));
    return () => { stale = true; };
  }, [src.source, src.chunk]);

  const rects = data?.highlight?.found ? data.highlight.rects : [];

  // Cuộn tới đúng chỗ được bôi sáng
  function scrollToHighlight() {
    if (!rects.length || !scroller.current || !pagebox.current) return;
    const top = pagebox.current.offsetTop + rects[0].y * pagebox.current.clientHeight - 70;
    scroller.current.scrollTo({ top: Math.max(top, 0), behavior: "smooth" });
  }
  useEffect(() => { scrollToHighlight(); }, [zoom]);

  return (
    <aside className="panel">
      <div className="panel-head">
        <b>Nguồn trích dẫn</b>
        <button className="icon-btn" title="Đóng" onClick={onClose}>✕</button>
      </div>

      <div className="tabs">
        {sources.map((s) => (
          <button key={s.n} className={"tab" + (s.n === src.n ? " on" : "")} onClick={() => onSelect(s.n)}>
            <span className="num">{s.n}</span>
            <span className="tname">{baseName(s.source)}</span>
            <small>{s.page ? `trang ${s.page}` : `đoạn ${s.chunk}`} · {Math.round(s.score * 100)}%{cited.includes(s.n) ? " · đã dùng" : ""}</small>
          </button>
        ))}
      </div>

      <div className="viewer" ref={scroller}>
        {error && <div className="error pad">{error}</div>}
        {!data && !error && <div className="hint">Đang tải nguồn...</div>}

        {data && data.kind === "pdf" && (
          <div className="pagebox" ref={pagebox} style={{ width: `${zoom * 100}%` }}>
            <img src={pageUrl(data.source, data.page)} alt={`Trang ${data.page}`} onLoad={scrollToHighlight} />
            {rects.map((r, i) => (
              <div
                key={i}
                className="hl"
                style={{ left: `${(r.x - 0.004) * 100}%`, top: `${(r.y - 0.002) * 100}%`, width: `${(r.w + 0.008) * 100}%`, height: `${(r.h + 0.004) * 100}%` }}
              />
            ))}
          </div>
        )}

        {data && data.kind !== "pdf" && (
          <div className="textsrc"><mark>{data.text}</mark></div>
        )}
      </div>

      {data && (
        <div className="panel-foot">
          {data.kind === "pdf" && !rects.length && (
            <div className="hint">Không xác định được vị trí chính xác trên trang, xem đoạn trích bên dưới.</div>
          )}
          {data.kind === "pdf" && (
            <div className="zoom">
              <button className="icon-btn" onClick={() => setZoom((z) => Math.max(0.6, +(z - 0.2).toFixed(1)))}>−</button>
              <span>{Math.round(zoom * 100)}%</span>
              <button className="icon-btn" onClick={() => setZoom((z) => Math.min(3, +(z + 0.2).toFixed(1)))}>＋</button>
              <a href={fileUrl(data.source)} target="_blank" rel="noreferrer">Mở file gốc</a>
            </div>
          )}
          {data.kind === "pdf" && <details><summary>Đoạn được lấy ({data.text.length} ký tự)</summary><p>{data.text}</p></details>}
        </div>
      )}
    </aside>
  );
}
