import { useEffect, useRef, useState } from "react";
import Bubble from "./Bubble";

const SUGGESTIONS = [
  "Tài liệu nói gì về quy định này?",
  "Tóm tắt nội dung chính của tài liệu",
  "Điều kiện để được xét học bổng là gì?",
  "Thời hạn nộp hồ sơ là khi nào?",
];

export default function ChatWindow({ user, chat, busy, collapsed, onOpenSidebar, onSend, onCite }) {
  const [input, setInput] = useState("");
  const endRef = useRef(null);
  const taRef = useRef(null);
  const msgs = chat ? chat.msgs : [];
  const lastContent = msgs.length ? msgs[msgs.length - 1].content : "";

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [msgs.length, lastContent]);

  function submit(text) {
    const t = (text ?? input).trim();
    if (!t || busy) return;
    setInput("");
    if (taRef.current) taRef.current.style.height = "auto";
    onSend(t);
  }

  function grow(e) {
    setInput(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 140) + "px";
  }

  return (
    <section className="main">
      <div className="top">
        <button className={"icon-btn menu" + (collapsed ? " show" : "")} title="Mở thanh bên" onClick={onOpenSidebar}>☰</button>
        <b>{chat ? chat.title : "AI_QNU"}</b>
      </div>

      <div className="msgs">
        <div className="wrap">
          {!chat && (
            <div className="empty">
              <div className="logo big">QNU</div>
              <h2>Xin chào, {user.name}!</h2>
              <div>Hỏi bất kỳ điều gì trong kho tài liệu của bạn.</div>
              <div className="chips">
                {SUGGESTIONS.map((s) => (
                  <button key={s} className="chip" onClick={() => submit(s)}>{s}</button>
                ))}
              </div>
            </div>
          )}
          {msgs.map((m, i) => (
            <Bubble
              key={i}
              role={m.role === "user" ? "user" : "bot"}
              isLast={msgs[i + 1]?.role !== m.role}
              msg={m}
              onCite={(n) => onCite(i, n)}
            />
          ))}
          <div ref={endRef} />
        </div>
      </div>

      <div className="bar">
        <div className="box">
          <textarea
            ref={taRef} rows="1" placeholder="Hỏi về tài liệu..." value={input}
            onChange={grow}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); } }}
          />
          <button className="send" disabled={busy || !input.trim()} onClick={() => submit()}>↑</button>
        </div>
        <div className="note">Câu trả lời chỉ dựa trên tài liệu đã nạp. Bấm số [1], [2] để xem đúng đoạn được lấy.</div>
      </div>
    </section>
  );
}
