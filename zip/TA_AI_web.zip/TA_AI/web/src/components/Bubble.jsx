const baseName = (p) => p.split("/").pop();

// Biến [1], [2]... trong câu trả lời thành nút bấm mở nguồn bên phải
function renderText(text, sources, onCite) {
  if (!sources?.length) return text;
  return text.split(/(\[\d+\])/g).map((part, i) => {
    const m = part.match(/^\[(\d+)\]$/);
    if (m && sources.some((s) => s.n === +m[1])) {
      return <button key={i} className="cite" onClick={() => onCite(+m[1])}>{m[1]}</button>;
    }
    return part;
  });
}

// role: "user" | "bot". isLast = true thì hiện đuôi bong bóng (kiểu iOS)
export default function Bubble({ role, isLast, msg, onCite }) {
  const sources = msg.sources || [];
  return (
    <div className={`row ${role}${isLast ? "" : " cont"}`}>
      <div className="bubble">
        {msg.content ? renderText(msg.content, sources, onCite) : <span className="dots"><i /><i /><i /></span>}
        {sources.length > 0 && (
          <div className="srcs">
            {sources.map((s) => (
              <button
                key={s.n}
                className={"src" + (msg.cited?.includes(s.n) ? " cited" : "")}
                title={s.source}
                onClick={() => onCite(s.n)}
              >
                {s.n} · {baseName(s.source)}{s.page ? ` · tr.${s.page}` : ""}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
