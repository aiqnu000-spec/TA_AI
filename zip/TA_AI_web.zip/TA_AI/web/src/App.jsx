import { useEffect, useState } from "react";
import { ls } from "./lib/storage";
import Login from "./components/Login";
import Chat from "./components/Chat";

export default function App() {
  const [theme, setTheme] = useState(
    () =>
      ls.get("qnu_theme", null) ||
      (window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light")
  );
  const [user, setUser] = useState(() => ls.get("qnu_session", null));

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    ls.set("qnu_theme", theme);
  }, [theme]);

  const toggleTheme = () => setTheme((t) => (t === "dark" ? "light" : "dark"));

  const handleLogin = (u) => {
    ls.set("qnu_session", u);
    setUser(u);
  };
  const handleLogout = () => {
    ls.set("qnu_session", null);
    setUser(null);
  };

  return user ? (
    <Chat user={user} theme={theme} onToggleTheme={toggleTheme} onUser={handleLogin} onLogout={handleLogout} />
  ) : (
    <Login theme={theme} onToggleTheme={toggleTheme} onLogin={handleLogin} />
  );
}
