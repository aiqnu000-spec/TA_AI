import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// /api/* được chuyển sang server Express (cổng 8000) khi chạy dev
export default defineConfig({
  plugins: [react()],
  server: { proxy: { "/api": "http://localhost:8000" } },
});
