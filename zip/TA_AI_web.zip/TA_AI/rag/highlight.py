"""
Tìm vị trí của một chunk trên trang PDF để giao diện web bôi sáng đúng đoạn được RAG lấy.

Cách làm: lấy toàn bộ TỪ của trang (kèm toạ độ) từ PyMuPDF, rồi căn chỉnh dãy từ của
chunk với dãy từ của trang (difflib). Cách này chịu được việc PDF ngắt dòng giữa câu,
chunker gộp khoảng trắng, hay chunk có phần gối đầu (overlap).

Kết quả là các hình chữ nhật (mỗi dòng chữ một hình) theo TỈ LỆ 0..1 của trang, nên
giao diện vẽ chồng lên ảnh trang ở bất kỳ độ phóng to nào cũng đúng.
"""
import difflib
import unicodedata
from pathlib import Path

MIN_RUN = 3        # đoạn khớp ngắn hơn số từ này bị coi là trùng hợp ngẫu nhiên ("của", "và"...)
CLUSTER_GAP = 15   # các đoạn khớp cách nhau quá số từ này thì coi là hai chỗ khác nhau


def _norm(token: str) -> str:
    return unicodedata.normalize("NFC", token).replace("\u00ad", "").lower()


def locate(path: Path, page_no: int, chunk_text: str) -> dict:
    """Trả về {"found", "rects": [{x,y,w,h}], "page_w", "page_h", "coverage"}."""
    import pymupdf

    with pymupdf.open(path) as doc:
        if not 1 <= page_no <= doc.page_count:
            raise ValueError(f"Trang {page_no} không tồn tại (file có {doc.page_count} trang)")
        page = doc[page_no - 1]
        width, height = page.rect.width, page.rect.height
        words = sorted(page.get_text("words"), key=lambda w: (w[5], w[6], w[7]))

    result = {"found": False, "rects": [], "page_w": width, "page_h": height, "coverage": 0.0}
    page_tokens = [_norm(w[4]) for w in words]
    chunk_tokens = [_norm(t) for t in chunk_text.split()]
    if not page_tokens or not chunk_tokens:
        return result

    matcher = difflib.SequenceMatcher(None, page_tokens, chunk_tokens, autojunk=False)
    matches = [b for b in matcher.get_matching_blocks() if b.size > 0]
    blocks = [b for b in matches if b.size >= MIN_RUN]
    if not blocks and len(chunk_tokens) < MIN_RUN:      # chunk rất ngắn: chấp nhận khớp ngắn
        blocks = matches
    if not blocks:
        return result

    # Gom các đoạn khớp ở gần nhau thành cụm, lấy cụm khớp nhiều từ nhất
    blocks.sort(key=lambda b: b.a)
    clusters = [[blocks[0]]]
    for b in blocks[1:]:
        prev = clusters[-1][-1]
        if b.a - (prev.a + prev.size) <= CLUSTER_GAP:
            clusters[-1].append(b)
        else:
            clusters.append([b])
    best = max(clusters, key=lambda c: sum(b.size for b in c))
    start, end = best[0].a, best[-1].a + best[-1].size
    matched = sum(b.size for b in best)

    # Gộp các từ trong khoảng [start, end) thành một hình chữ nhật cho mỗi dòng chữ
    lines: dict[tuple[int, int], list[float]] = {}
    for w in words[start:end]:
        r = lines.setdefault((w[5], w[6]), [w[0], w[1], w[2], w[3]])
        r[0], r[1] = min(r[0], w[0]), min(r[1], w[1])
        r[2], r[3] = max(r[2], w[2]), max(r[3], w[3])
    rects = [
        {"x": r[0] / width, "y": r[1] / height, "w": (r[2] - r[0]) / width, "h": (r[3] - r[1]) / height}
        for r in sorted(lines.values(), key=lambda r: (round(r[1]), r[0]))
    ]
    result.update(found=True, rects=rects, coverage=round(matched / len(chunk_tokens), 3))
    return result


def render_page(path: Path, page_no: int, zoom: float = 1.6) -> bytes:
    """Vẽ trang PDF thành ảnh PNG."""
    import pymupdf

    with pymupdf.open(path) as doc:
        if not 1 <= page_no <= doc.page_count:
            raise ValueError(f"Trang {page_no} không tồn tại")
        pix = doc[page_no - 1].get_pixmap(matrix=pymupdf.Matrix(zoom, zoom), alpha=False)
        return pix.tobytes("png")
