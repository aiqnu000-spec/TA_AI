"""Kiểm tra bôi sáng: toạ độ trả về phải nằm đúng chỗ chunk trên trang PDF."""
import pymupdf

from rag.chunker import make_chunks
from rag.highlight import locate
from rag.loaders import load_pdf

PAGE1 = ("Introduction. This document describes the library opening hours and rules. "
         "Students may borrow up to five books at a time for two weeks. ") * 2
TARGET = ("The reading room closes at nine in the evening on weekdays and at five on weekends, "
          "and silence must be kept at all times inside the reading room.")


def _make_pdf(path):
    doc = pymupdf.open()
    p1 = doc.new_page()
    p1.insert_textbox(pymupdf.Rect(50, 50, 545, 300), PAGE1, fontsize=11)
    p2 = doc.new_page()
    p2.insert_textbox(pymupdf.Rect(50, 50, 545, 150), "Page two header text goes here for padding only.", fontsize=11)
    p2.insert_textbox(pymupdf.Rect(50, 400, 545, 520), TARGET, fontsize=11)  # nằm ở NỬA DƯỚI trang
    doc.save(path)
    doc.close()


def test_highlight_points_to_the_right_place(tmp_path):
    pdf = tmp_path / "rules.pdf"
    _make_pdf(pdf)
    chunks = make_chunks(load_pdf(pdf).segments)
    chunk = next(c for c in chunks if "reading room closes" in c.text)
    assert chunk.page == 2

    # Chunk gồm cả dòng tiêu đề (đầu trang) lẫn câu mục tiêu (nửa dưới) -> bôi sáng phủ cả hai
    res = locate(pdf, chunk.page, chunk.text)
    assert res["found"] and res["coverage"] > 0.8
    assert min(r["y"] for r in res["rects"]) < 0.1 and max(r["y"] for r in res["rects"]) > 0.45

    # Chỉ riêng câu mục tiêu: bôi sáng PHẢI nằm ở nửa dưới (y = 400/842 ~ 0.475), không lẫn phần đầu trang
    only = locate(pdf, 2, TARGET)
    assert only["found"] and only["coverage"] > 0.9
    assert min(r["y"] for r in only["rects"]) > 0.45
    assert all(0 <= r["x"] <= 1 and r["w"] > 0 for r in only["rects"])


def test_highlight_wrong_text_is_not_found(tmp_path):
    pdf = tmp_path / "rules.pdf"
    _make_pdf(pdf)
    res = locate(pdf, 1, "completely unrelated sentence about astronomy and telescopes")
    assert not res["found"]
