# Giai đoạn 1 - Lõi RAG (chạy bằng dòng lệnh)

Xem hướng dẫn đầy đủ trong tin nhắn trả lời. Tóm tắt lệnh:

    py -3.14 -m venv .venv && .venv\Scripts\activate
    pip install -r requirements.txt -r requirements-rag.txt
    ollama pull bge-m3 && ollama pull qwen2.5:7b
    python rag_cli.py check
    python rag_cli.py ingest
    python rag_cli.py ask "câu hỏi" --debug
    python rag_eval.py
    pytest -q

---

# Giai đoạn Web - AI_QNU (React + FastAPI)

Giao diện chat kiểu ChatGPT dùng lõi RAG ở trên. Khi câu trả lời lấy thông tin từ tài liệu,
**bảng bên phải** mở ra, hiện đúng trang PDF và **bôi sáng đúng đoạn** đã được lấy.

```
rag_api.py            API FastAPI bọc lõi RAG (chat streaming, ảnh trang PDF, vị trí bôi sáng)
rag/highlight.py      tìm vị trí chunk trên trang PDF (căn từ-với-từ bằng PyMuPDF)
web/                  giao diện React + Vite (web/src/components/SourcePanel.jsx là bảng bên phải)
```

## Chạy

```bash
# 0) như giai đoạn 1: ollama pull bge-m3 && ollama pull qwen2.5:7b
#    bỏ PDF vào data/documents/ rồi:
python rag_cli.py ingest

# 1) API (cổng 8000)
pip install -r requirements.txt
uvicorn rag_api:app --port 8000

# 2) Web (cổng 5173) - terminal khác
cd web
npm install
npm run dev
```

Mở http://localhost:5173, hỏi một câu liên quan tài liệu. Bấm số [1], [2] trong câu trả lời
(hoặc thẻ nguồn dưới bong bóng) để xem đúng vị trí.

Thêm tài liệu mới: bỏ file vào `data/documents/` rồi `python rag_cli.py ingest`
(hoặc `curl -X POST localhost:8000/api/ingest`).

## Giới hạn hiện tại
- PDF scan (ảnh) chưa có OCR nên không có chữ để bôi sáng (giống giai đoạn 1).
- DOCX/TXT/MD không có "trang" nên bảng bên phải hiện đoạn văn được lấy, được tô sáng.
- Mỗi câu hỏi tra cứu độc lập (chưa nhớ ngữ cảnh các câu trước).
- Đăng nhập web là bản demo lưu trong trình duyệt.
